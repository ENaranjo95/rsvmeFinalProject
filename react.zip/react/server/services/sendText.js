// Twilio Requires
const MessagingResponse = require('twilio').twiml.MessagingResponse;
const smsClient = require('../services/twilio')

let sendText = (req, res) =>{
  smsClient.messages.create({
     body: `Your table ${req.body.table} is reserved for this time ${req.body.time}!`,
     from: '+16179103731',
     to: `+1${req.body.phone}`
   })
  .then(message => console.log(message.sid))
  .done();
}

module.exports = sendText
