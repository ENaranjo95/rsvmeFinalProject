import React, { Component } from 'react'

class Home extends Component {

  render() {
    return (
      <main>
        <img id="img" src='../img/table.jpg' alt="Restaurant Table" />
      </main>
    );
  }
}

export default Home
