import React from 'react';
import './Tables.css';

class Other {

  render(){
    return (
      <section className="space">
        <section className="column">
          <div className="checkIn">Check In</div>
        </section>
        <section className="column">
          <div className="bar">Bar</div>
        </section>
      </section>
    )
  }
}

export default Other;
